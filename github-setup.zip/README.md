<div align="center">

# 🛍️ ShopEasy — Full-Stack E-Commerce App

**Shop smarter. Live better.**
An online store with a customer storefront and an admin panel, built with Angular and Spring Boot.

[![CI](https://github.com/Ritesh10506/ecommerce-app/actions/workflows/ci.yml/badge.svg)](https://github.com/Ritesh10506/ecommerce-app/actions/workflows/ci.yml)
![Java](https://img.shields.io/badge/Java-21-orange?logo=openjdk)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot-4-6DB33F?logo=springboot&logoColor=white)
![Angular](https://img.shields.io/badge/Angular-21-DD0031?logo=angular&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-8-4479A1?logo=mysql&logoColor=white)

<img src="docs/screenshots/hero.png" alt="ShopEasy home page" width="900">

</div>

---

## 📌 About

ShopEasy is a full-stack e-commerce web application built during HCL training. Customers can browse products, manage a cart, check out and track orders. Admins get a dedicated panel to manage products, categories, orders and users.

### Why ShopEasy?

<div align="center">
  <img src="docs/screenshots/features.png" alt="Fast delivery, secure payments, easy cancellation" width="900">
</div>

| | Feature | What it means |
|---|---|---|
| 🚚 | **Fast delivery** | Orders are dispatched within 24 hours |
| 🔒 | **Secure payments** | Protected with JWT authentication and BCrypt-hashed passwords |
| 🔄 | **Easy cancellation** | Cancel an order before it ships, and stock is restored automatically |

### Store at a glance

<div align="center">
  <img src="docs/screenshots/stats.png" alt="Store stats: products, categories, dispatch time" width="620">
</div>

---

## 📸 Screenshots

> Add your own screenshots to `docs/screenshots/` using the file names below.

### Shopping cart: add and remove items

| Add to cart | Update quantity | Remove from cart |
|:---:|:---:|:---:|
| <img src="docs/screenshots/add-to-cart.png" alt="Add to cart" width="280"> | <img src="docs/screenshots/cart.png" alt="Cart with quantity controls" width="280"> | <img src="docs/screenshots/remove-from-cart.png" alt="Remove from cart" width="280"> |

### Customer storefront

| Product listing | Product detail | Checkout |
|:---:|:---:|:---:|
| <img src="docs/screenshots/products.png" alt="Product listing" width="280"> | <img src="docs/screenshots/product-detail.png" alt="Product detail" width="280"> | <img src="docs/screenshots/checkout.png" alt="Checkout" width="280"> |

| My orders | Login | Sign up |
|:---:|:---:|:---:|
| <img src="docs/screenshots/my-orders.png" alt="My orders" width="280"> | <img src="docs/screenshots/login.png" alt="Login" width="280"> | <img src="docs/screenshots/register.png" alt="Register" width="280"> |

### Admin panel

| Dashboard | Products | Orders |
|:---:|:---:|:---:|
| <img src="docs/screenshots/admin-dashboard.png" alt="Admin dashboard" width="280"> | <img src="docs/screenshots/admin-products.png" alt="Admin products" width="280"> | <img src="docs/screenshots/admin-orders.png" alt="Admin orders" width="280"> |

---

## ✨ Features

**Customer**
- Register and log in with JWT authentication
- Browse products, search by name and filter by category
- Product detail page with stock information
- Shopping cart with stock validation, quantity update and remove
- Checkout and order placement
- Order history with status tracking and cancellation (stock is restored)

**Admin**
- Dashboard with store statistics
- Manage products (create, edit, delete) and categories
- View and update order status
- Manage users

**Platform**
- Role-based access control (`ADMIN` and `CUSTOMER`)
- BCrypt password hashing
- Global exception handling and request validation
- Route guards and an HTTP interceptor on the frontend

---

## 🧰 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Angular 21 (standalone components, signals), TypeScript, RxJS |
| Backend | Java 21, Spring Boot 4, Spring Data JPA (Hibernate), Spring Security |
| Auth | JWT (jjwt 0.12), BCrypt |
| Database | MySQL 8 |
| Build | Maven (backend), Angular CLI (frontend) |
| CI | GitHub Actions |

---

## 📁 Project Structure

```
ecommerce-app/
├── backend/                     # Spring Boot REST API
│   └── src/main/java/com/hcl/e_comerce/
│       ├── config/              # Security config, admin data seeder
│       ├── controller/          # REST controllers
│       ├── dto/                 # Request / response objects
│       ├── entity/              # JPA entities
│       ├── exception/           # Global error handling
│       ├── repository/          # Spring Data repositories
│       ├── security/            # JWT filter and utilities
│       └── service/             # Business logic
├── frontend/                    # Angular app
│   └── src/app/
│       ├── core/                # Services, guards, interceptor, models
│       ├── layouts/             # Store layout and admin layout
│       ├── pages/               # auth/, store/, admin/
│       └── shared/              # Reusable components
├── docs/screenshots/            # README images
└── .github/workflows/ci.yml     # CI pipeline
```

---

## 🚀 Getting Started

### Prerequisites
- Java 21
- Node.js 20.19+ or 22+ and npm
- MySQL 8

### 1. Clone the repository

```bash
git clone https://github.com/Ritesh10506/ecommerce-app.git
cd ecommerce-app
```

### 2. Run the backend

```sql
CREATE DATABASE ecommerce_db;
```

```bash
cd backend
cp .env.example .env      # then fill in your values
./mvnw spring-boot:run
```

The API runs on **http://localhost:8081**.

`backend/.env`:

| Variable | Description |
|---|---|
| `DB_USERNAME` | MySQL username |
| `DB_PASSWORD` | MySQL password |
| `JWT_SECRET` | Random string, at least 32 characters |

> The MySQL port in `backend/src/main/resources/application.properties` is set to `3506`. Change it to `3306` if you use the default.

**Default admin account:** `admin@shop.com` / `admin123`. Change this password before deploying anywhere public.

### 3. Run the frontend

```bash
cd frontend
npm install
npm start
```

Open **http://localhost:4200**. The API URL is configured in `frontend/src/app/core/api.ts`.

---

## 🔌 API Overview

| Module | Endpoints |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me` |
| Products | `GET /api/products`, `GET /api/products/{id}`, `GET /api/products/category/{categoryId}`, `GET /api/products/search?name=`, `POST` / `PUT` / `DELETE` (admin) |
| Categories | `GET /api/categories`, `GET /api/categories/{id}`, `POST` (admin) |
| Cart | `GET /api/cart/{userId}`, `POST /api/cart/{userId}/add`, `PUT /api/cart/item/{cartItemId}`, `DELETE /api/cart/item/{cartItemId}`, `DELETE /api/cart/{userId}/clear`, `POST /api/cart/{userId}/checkout` |
| Orders | `GET /api/orders`, `GET /api/orders/{id}`, `GET /api/orders/user/{userId}`, `PUT /api/orders/{id}/status`, `PUT /api/orders/{id}/cancel` |
| Users | `GET /api/users`, `GET /api/users/{id}`, `DELETE /api/users/{id}` |

---

## ⚙️ Continuous Integration

Every push and pull request to `main` runs [`ci.yml`](.github/workflows/ci.yml):

1. **Backend:** starts a MySQL 8 service, then runs `./mvnw verify` on JDK 21.
2. **Frontend:** runs `npm ci` and a production `ng build` on Node 22.

---

## 🗺️ Roadmap

- [ ] Online payment gateway integration
- [ ] Product image upload
- [ ] Wishlist and product reviews
- [ ] Unit tests for the frontend
- [ ] Docker Compose setup

---

## 👤 Author

**Ritesh Singh** — B.Tech CSE, ABES Engineering College
GitHub: [@Ritesh10506](https://github.com/Ritesh10506)
